import { Menu } from "antd";
import Sider from "antd/es/layout/Sider";
import React, { useEffect, useState } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import {
  MailOutlined,
  AppstoreOutlined,
  SettingOutlined,
  DashboardOutlined,
  AreaChartOutlined,
  FolderOutlined,
  FileOutlined,
  GlobalOutlined,
  EnvironmentOutlined,
  AimOutlined,
  BankOutlined,
  FileTextOutlined,
  UserOutlined,
  HistoryOutlined,
  EyeOutlined,
} from "@ant-design/icons";
import styled from "styled-components";
import ReactSvg from "../../assets/logo.png";
import authService from "../../api/auth.service";
import { useTranslation } from "react-i18next";

const rootSubmenuKeys = ["sub1", "sub2", "sub4"];
const Sidebar = ({ collapsed }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const keys = JSON.parse(localStorage.getItem("keyPath"));
  const [openKeys, setOpenKeys] = useState(keys ? keys[keys.length - 1] : []);
  const path = location.pathname;
  const [current, setCurrent] = useState(["dashboard"]);
  const [items, setItems] = useState([]);
  const { t, i18n } = useTranslation();

  const onClick = (e) => {
    console.log("click ", e);
    setCurrent(e.key);

    navigate(e.key);
    setOpenKeys(e.keyPath);

    const y = JSON.parse(localStorage.getItem("keyPath")) || [];

    localStorage.setItem("keyPath", JSON.stringify([...y, e.keyPath]));
  };

  const onOpenChange = (keys) => {
    const latestOpenKey = keys.find((key) => openKeys.indexOf(key) === -1);

    if (latestOpenKey && rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
      setOpenKeys(keys);
    } else {
      setOpenKeys(latestOpenKey ? [latestOpenKey] : []);
    }
  };
  useEffect(() => {
    getItems();
  }, []);
  useEffect(() => {
    const x = [...path.split("/")];
    console.log("ppppppppppppp", x);
    setCurrent(x.length > 2 ? x[x.length - 1] : "");
    const y = JSON.parse(localStorage.getItem("keyPath")) || [];

    setOpenKeys(y ? y[y.length - 1] : []);
  }, [path]);

  function getItem(
    label,
    key,
    icon,
    children,
    type,
    disabled = false,
    style = {}
  ) {
    return {
      key,
      icon,
      children,
      label,
      type,
      disabled,
      style,
    };
  }
  const getItems = async () => {
    const items2 = [
      getItem(
        <p className="text-gray-500">{t("OVERVIEW")}</p>,
        "dashboard",
        null,
        null,
        null,
        true
      ),

      getItem(t("Dashboard"), "", <DashboardOutlined />),

      (await authService.checkPermmision("documents", "readOnly")) &&
        getItem(t("Documents"), "documents", <FileOutlined />),
      // getItem("Reports", "reports", <DashboardOutlined />),
      (await authService.checkPermmision("documents", "readOnly")) &&
        getItem(
          <p className="text-gray-500">{t("AREAS")}</p>,
          "dashboard",
          null,
          null,
          null,
          true
        ),
      (await authService.checkPermmision("state", "readOnly")) &&
        getItem(t("State"), "state", <GlobalOutlined />),
      (await authService.checkPermmision("zone", "readOnly")) &&
        getItem(t("Zone"), "zone", <EnvironmentOutlined />),
      (await authService.checkPermmision("woreda", "readOnly")) &&
        getItem(t("Woreda"), "woreda", <DashboardOutlined />),
      (await authService.checkPermmision("kebele", "readOnly")) &&
        getItem(t("Kebele"), "kebele", <DashboardOutlined />),
      (await authService.checkPermmision("village", "readOnly")) &&
        getItem(t("Village"), "village", <DashboardOutlined />),
      getItem(
        <p className="text-gray-500">{t("Data")}</p>,
        "dashboard",
        null,
        null,
        null,
        true
      ),

      (await authService.checkPermmision("facilityList", "readOnly")) &&
        getItem(t("Facility"), "facilityList", <BankOutlined />),
        
        getItem(t("Facility_history") , "facilityHistory", <HistoryOutlined />),

      (await authService.checkPermmision("service", "readOnly")) &&
        getItem(t("Report"), "service", <FileTextOutlined />),

      (await authService.checkPermmision("serviceProvider", "readOnly")) &&
        getItem(t("ServiceProvider"), "serviceProvider", <UserOutlined />),

      // (await authService.checkPermmision("history", "readOnly")) &&
      //   getItem(t("History"), "history", <HistoryOutlined />),

      getItem(
        <p className="text-gray-500">{t("SETTINGS")}</p>,
        "dashboard",
        null,
        null,
        null,
        true
      ),
      // 	region@hundee.com  +251911011101
      // getItem("Setting", "sub1", <MailOutlined />, [
      (await authService.checkPermmision("sectors", "readOnly")) &&
        getItem(t("Sectors"), "sectors", <AppstoreOutlined />),
      (await authService.checkPermmision("document_types", "readOnly")) &&
        getItem(t("Document_types"), "document_types", <FileOutlined />),
      (await authService.checkPermmision("care_takers", "readOnly")) &&
        getItem(t("Facility_Monitors"), "care_takers", <EyeOutlined />),
      (await authService.checkPermmision("users", "readOnly")) &&
        getItem(t("Users"), "users", <UserOutlined />),

      // ]),

      // getItem("Navigation Two", "sub2", <AppstoreOutlined />, [
      //   getItem("Option 5", "5"),
      //   getItem("Option 6", "6"),
      //   getItem("Submenu", "sub3", null, [
      //     getItem("Option 7", "7"),
      //     getItem("Option 8", "8"),
      //   ]),
      // ]),
      // getItem("Navigation Three", "sub4", <SettingOutlined />, [
      //   getItem("Option 9", "9"),
      //   getItem("Option 10", "10"),
      //   getItem("Option 11", "11"),
      //   getItem("Option 12", "12"),
      // ]),

      // getItem("setting", "15"),
      // getItem("setting", "16"),
    ];

    setItems(items2);
  };

  return (
    <SidebarStyle
      width={250}
      style={{
        height: "100vh",
        // border: "1px solid gray",
        borderRadius: "0px 40px 40px 0",
        position: "fixed",
        display: collapsed && "none",
        backgroundColor: "white",
        zIndex: 110,
      }}
      trigger={null}
      collapsible
      collapsed={collapsed}
    >
      <div className="demo-logo-vertical" />
      <div
        className="flex  justify-center items-center"
        style={{
          width: 249,
          height: 100,
          background: "white",
          borderRadius: "0px 40px 0 0",
        }}
      >
        <NavLink to={"/home"}>
          <img
            src={ReactSvg}
            color="white"
            className="w-40 h-20    text-black border-red-800"
            alt="MK Logo"
          />
        </NavLink>
      </div>
      <div className="sidebar__menus">
        <Menu
          theme={"dark"}
          onClick={onClick}
          style={{
            backgroundColor: "transparent",
          }}
          openKeys={openKeys}
          onOpenChange={onOpenChange}
          selectedKeys={current}
          mode="inline"
          items={items}
        />
      </div>
    </SidebarStyle>
  );
};

const SidebarStyle = styled(Sider)`
  .sidebar__menus {
    overflow: auto;
    overflow-x: hidden;
    height: calc(100vh - 100px);
  }
  .ant-menu-sub {
    background-color: transparent !important;
  }

  .ant-menu-item-selected {
    background-color: #3bb66e !important;
    color: white !important;
  }
  span {
    font-size: 13px !important;
    color: black !important;
  }
  .ant-menu-item-selected span {
    color: white !important;
  }
`;

export default Sidebar;
